# Glass Clock

An iPhone-style lock screen clock for Android, built as a live wallpaper with a settings screen.

## Run it
1. Open this folder in Android Studio and let Gradle sync (accept any suggested AGP/Gradle upgrade).
2. On the Redmi 15: Settings > About phone > tap the OS version 7 times, then in Additional settings > Developer options turn on USB debugging (and "Install via USB" if shown).
3. Plug in the phone and press Run. (Or Build > Build APK and install the APK.)
4. In the app, tune the clock, then tap "Set as wallpaper" and choose Lock screen (or both).

## Notes
- The clock, and the background photo, are drawn by the wallpaper itself. HyperOS may still draw its own clock on top: change the lock screen style (long-press lock screen > Next) or move ours with the Vertical position slider.
- Custom font: import any .ttf/.otf you have the licence for (for example Inter, which looks close to the iOS clock).
- Battery: the clock only redraws once a minute while the screen is showing it.
