package com.sarthak.glassclock

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.text.format.DateFormat

data class ClockConfig(
    val style: Int,
    val fontIndex: Int,
    val customFontPath: String?,
    val color: Int,
    val sizePercent: Int,
    val yPercent: Int,
    val opacityPercent: Int,
    val dimPercent: Int,
    val use24h: Boolean,
    val showDate: Boolean,
    val glass: Boolean,
    val bgImagePath: String?
)

object ClockPrefs {
    const val STYLE_HORIZONTAL = 0
    const val STYLE_STACKED = 1
    const val FONT_CUSTOM = 6

    const val KEY_STYLE = "style"
    const val KEY_FONT = "font"
    const val KEY_FONT_PATH = "font_path"
    const val KEY_COLOR = "color"
    const val KEY_SIZE = "size"
    const val KEY_Y = "y"
    const val KEY_OPACITY = "opacity"
    const val KEY_DIM = "dim"
    const val KEY_24H = "use24h"
    const val KEY_DATE = "show_date"
    const val KEY_GLASS = "glass"
    const val KEY_BG = "bg_path"

    const val DEF_SIZE = 100
    const val DEF_Y = 22
    const val DEF_OPACITY = 95
    const val DEF_DIM = 15

    fun prefs(context: Context): SharedPreferences =
        context.applicationContext.getSharedPreferences("glass_clock", Context.MODE_PRIVATE)

    fun default24h(context: Context): Boolean = DateFormat.is24HourFormat(context)

    fun load(context: Context): ClockConfig {
        val p = prefs(context)
        return ClockConfig(
            style = p.getInt(KEY_STYLE, STYLE_HORIZONTAL),
            fontIndex = p.getInt(KEY_FONT, 0),
            customFontPath = p.getString(KEY_FONT_PATH, null),
            color = p.getInt(KEY_COLOR, Color.WHITE),
            sizePercent = p.getInt(KEY_SIZE, DEF_SIZE),
            yPercent = p.getInt(KEY_Y, DEF_Y),
            opacityPercent = p.getInt(KEY_OPACITY, DEF_OPACITY),
            dimPercent = p.getInt(KEY_DIM, DEF_DIM),
            use24h = p.getBoolean(KEY_24H, default24h(context)),
            showDate = p.getBoolean(KEY_DATE, true),
            glass = p.getBoolean(KEY_GLASS, true),
            bgImagePath = p.getString(KEY_BG, null)
        )
    }
}
