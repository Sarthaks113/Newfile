package com.sarthak.glassclock

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Shader
import android.graphics.Typeface
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import kotlin.math.max

/**
 * Draws the whole lock screen picture (background + clock).
 * The same code is used by the live wallpaper and by the preview inside the app.
 */
class ClockRenderer(@Suppress("unused") private val context: Context) {

    private val timePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val datePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bgPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val gradPaint = Paint()
    private val bounds = Rect()

    private var bgBitmap: Bitmap? = null
    private var bgKey: String? = null

    private var typefaceKey: String? = null
    private var typeface: Typeface = Typeface.DEFAULT_BOLD

    fun draw(
        canvas: Canvas,
        w: Int,
        h: Int,
        cfg: ClockConfig,
        now: Calendar = Calendar.getInstance()
    ) {
        if (w <= 0 || h <= 0) return
        drawBackground(canvas, w, h, cfg)

        val scale = cfg.sizePercent / 100f
        val stacked = cfg.style == ClockPrefs.STYLE_STACKED

        timePaint.typeface = resolveTypeface(cfg)
        timePaint.textAlign = Paint.Align.CENTER
        timePaint.textSize = w * (if (stacked) 0.32f else 0.29f) * scale

        datePaint.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        datePaint.textAlign = Paint.Align.CENTER
        datePaint.textSize = w * 0.05f * scale

        val timeH = digitHeight(timePaint)
        val dateH = digitHeight(datePaint)

        val hour24 = now.get(Calendar.HOUR_OF_DAY)
        val minute = now.get(Calendar.MINUTE)
        val hourText = if (cfg.use24h) {
            "%02d".format(hour24)
        } else {
            val hh = hour24 % 12
            (if (hh == 0) 12 else hh).toString()
        }
        val minText = "%02d".format(minute)

        val gapDate = dateH * 0.9f
        val gapLines = timeH * 0.14f
        val timeBlockH = if (stacked) timeH * 2f + gapLines else timeH
        val blockH = timeBlockH + (if (cfg.showDate) dateH + gapDate else 0f)

        var top = h * cfg.yPercent / 100f - blockH / 2f
        top = top.coerceIn(0f, max(0f, h - blockH))

        val cx = w / 2f
        var y = top

        if (cfg.showDate) {
            val dateText = SimpleDateFormat("EEEE d MMMM", Locale.getDefault()).format(now.time)
            styleText(datePaint, cfg, y, y + dateH, 0.85f)
            canvas.drawText(dateText, cx, y + dateH, datePaint)
            y += dateH + gapDate
        }

        styleText(timePaint, cfg, y, y + timeBlockH, 1f)
        if (stacked) {
            canvas.drawText(hourText, cx, y + timeH, timePaint)
            canvas.drawText(minText, cx, y + timeH * 2f + gapLines, timePaint)
        } else {
            canvas.drawText("$hourText:$minText", cx, y + timeH, timePaint)
        }
    }

    /** Glass = vertical fade in the text colour plus a soft shadow, like the iOS clock. */
    private fun styleText(p: Paint, cfg: ClockConfig, top: Float, bottom: Float, alphaMul: Float) {
        val baseAlpha = (cfg.opacityPercent / 100f) * alphaMul
        if (cfg.glass) {
            val hi = withAlpha(cfg.color, (baseAlpha * 255f).toInt().coerceIn(0, 255))
            val lo = withAlpha(cfg.color, (baseAlpha * 0.62f * 255f).toInt().coerceIn(0, 255))
            p.shader = LinearGradient(0f, top, 0f, bottom, hi, lo, Shader.TileMode.CLAMP)
            // Paint colour stays opaque; the shader carries the transparency.
            p.color = Color.BLACK
            p.setShadowLayer(p.textSize * 0.06f, 0f, p.textSize * 0.03f, 0x40000000)
        } else {
            p.shader = null
            p.color = withAlpha(cfg.color, (baseAlpha * 255f).toInt().coerceIn(0, 255))
            p.clearShadowLayer()
        }
    }

    private fun withAlpha(color: Int, alpha: Int): Int = (color and 0x00FFFFFF) or (alpha shl 24)

    private fun digitHeight(p: Paint): Float {
        p.getTextBounds("0", 0, 1, bounds)
        return bounds.height().toFloat()
    }

    private fun resolveTypeface(cfg: ClockConfig): Typeface {
        val key = "${cfg.fontIndex}|${cfg.customFontPath}"
        if (key == typefaceKey) return typeface
        typefaceKey = key
        typeface = try {
            when (cfg.fontIndex) {
                1 -> Typeface.create("sans-serif-black", Typeface.NORMAL)
                2 -> Typeface.create("sans-serif-light", Typeface.NORMAL)
                3 -> Typeface.create("sans-serif-condensed", Typeface.BOLD)
                4 -> Typeface.create(Typeface.SERIF, Typeface.BOLD)
                5 -> Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
                ClockPrefs.FONT_CUSTOM ->
                    if (cfg.customFontPath != null) Typeface.createFromFile(cfg.customFontPath)
                    else Typeface.DEFAULT_BOLD
                else -> Typeface.create("sans-serif", Typeface.BOLD)
            }
        } catch (e: Exception) {
            Typeface.DEFAULT_BOLD
        }
        return typeface
    }

    private fun drawBackground(canvas: Canvas, w: Int, h: Int, cfg: ClockConfig) {
        val path = cfg.bgImagePath
        val bmp = if (path != null) loadBackground(path, w, h) else null
        if (bmp != null) {
            val s = max(w / bmp.width.toFloat(), h / bmp.height.toFloat())
            val dx = (w - bmp.width * s) / 2f
            val dy = (h - bmp.height * s) / 2f
            val m = Matrix().apply {
                postScale(s, s)
                postTranslate(dx, dy)
            }
            canvas.drawBitmap(bmp, m, bgPaint)
            if (cfg.dimPercent > 0) {
                canvas.drawColor(Color.argb((cfg.dimPercent / 100f * 255f).toInt(), 0, 0, 0))
            }
        } else {
            gradPaint.shader = LinearGradient(
                0f, 0f, 0f, h.toFloat(),
                intArrayOf(0xFF1F1147.toInt(), 0xFF4C3A9E.toInt(), 0xFFE38FA0.toInt()),
                floatArrayOf(0f, 0.55f, 1f),
                Shader.TileMode.CLAMP
            )
            canvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), gradPaint)
        }
    }

    private fun loadBackground(path: String, w: Int, h: Int): Bitmap? {
        val key = "$path@${w}x$h"
        if (key == bgKey) return bgBitmap
        bgKey = key
        bgBitmap = null
        return try {
            val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(path, opts)
            if (opts.outWidth <= 0 || opts.outHeight <= 0) return null
            var sample = 1
            while (opts.outWidth / (sample * 2) >= w && opts.outHeight / (sample * 2) >= h) {
                sample *= 2
            }
            val decode = BitmapFactory.Options().apply { inSampleSize = sample }
            bgBitmap = BitmapFactory.decodeFile(path, decode)
            bgBitmap
        } catch (e: Exception) {
            null
        }
    }
}
