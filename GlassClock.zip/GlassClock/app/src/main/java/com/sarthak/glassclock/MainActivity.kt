package com.sarthak.glassclock

import android.app.WallpaperManager
import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButtonToggleGroup
import com.google.android.material.materialswitch.MaterialSwitch

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var preview: ClockPreviewView
    private lateinit var fontSpinner: Spinner
    private lateinit var colorRow: LinearLayout

    private val colors = intArrayOf(
        0xFFFFFFFF.toInt(), 0xFFFFE0B2.toInt(), 0xFFFFCDD2.toInt(), 0xFFB3E5FC.toInt(),
        0xFFC8E6C9.toInt(), 0xFFFFF59D.toInt(), 0xFFE1BEE7.toInt(), 0xFF000000.toInt()
    )

    private val pickImage =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) runImport { ClockImport.importBackground(this, uri) }
        }

    private val pickFont =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) {
                runImport { ClockImport.importFont(this, uri) }
            } else {
                fontSpinner.setSelection(prefs.getInt(ClockPrefs.KEY_FONT, 0))
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = ClockPrefs.prefs(this)
        preview = findViewById(R.id.preview)
        fontSpinner = findViewById(R.id.fontSpinner)
        colorRow = findViewById(R.id.colorRow)

        bindStyle()
        bindFont()
        buildColorRow()

        bindSeek(R.id.seekSize, ClockPrefs.KEY_SIZE, ClockPrefs.DEF_SIZE, 50)
        bindSeek(R.id.seekY, ClockPrefs.KEY_Y, ClockPrefs.DEF_Y, 5)
        bindSeek(R.id.seekOpacity, ClockPrefs.KEY_OPACITY, ClockPrefs.DEF_OPACITY, 30)
        bindSeek(R.id.seekDim, ClockPrefs.KEY_DIM, ClockPrefs.DEF_DIM, 0)

        bindSwitch(R.id.switchGlass, ClockPrefs.KEY_GLASS, true)
        bindSwitch(R.id.switchDate, ClockPrefs.KEY_DATE, true)
        bindSwitch(R.id.switch24, ClockPrefs.KEY_24H, ClockPrefs.default24h(this))

        findViewById<View>(R.id.btnPickBg).setOnClickListener { pickImage.launch("image/*") }
        findViewById<View>(R.id.btnResetBg).setOnClickListener {
            ClockImport.clearBackground(this)
            preview.reload()
        }
        findViewById<View>(R.id.btnCustomFont).setOnClickListener { pickFont.launch("*/*") }
        findViewById<View>(R.id.btnApply).setOnClickListener { applyWallpaper() }
    }

    private fun bindStyle() {
        val group = findViewById<MaterialButtonToggleGroup>(R.id.styleToggle)
        group.check(
            if (prefs.getInt(ClockPrefs.KEY_STYLE, 0) == ClockPrefs.STYLE_STACKED) R.id.btnStacked
            else R.id.btnHorizontal
        )
        group.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (isChecked) {
                val style =
                    if (checkedId == R.id.btnStacked) ClockPrefs.STYLE_STACKED
                    else ClockPrefs.STYLE_HORIZONTAL
                prefs.edit().putInt(ClockPrefs.KEY_STYLE, style).apply()
                preview.reload()
            }
        }
    }

    private fun bindFont() {
        val names = listOf("Bold", "Black", "Light", "Condensed", "Serif", "Mono", "Custom file")
        fontSpinner.adapter =
            ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        fontSpinner.setSelection(prefs.getInt(ClockPrefs.KEY_FONT, 0))
        fontSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (pos == prefs.getInt(ClockPrefs.KEY_FONT, 0)) return
                if (pos == ClockPrefs.FONT_CUSTOM &&
                    prefs.getString(ClockPrefs.KEY_FONT_PATH, null) == null
                ) {
                    pickFont.launch("*/*")
                    return
                }
                prefs.edit().putInt(ClockPrefs.KEY_FONT, pos).apply()
                preview.reload()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    private fun buildColorRow() {
        colorRow.removeAllViews()
        val current = prefs.getInt(ClockPrefs.KEY_COLOR, Color.WHITE)
        for (c in colors) {
            val selected = c == current
            val dot = View(this)
            dot.layoutParams = LinearLayout.LayoutParams(dp(44), dp(44)).apply {
                marginEnd = dp(10)
            }
            dot.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(c)
                setStroke(
                    if (selected) dp(4) else dp(1),
                    if (selected) 0xFF3D7CFF.toInt() else 0x55888888
                )
            }
            dot.setOnClickListener {
                prefs.edit().putInt(ClockPrefs.KEY_COLOR, c).apply()
                preview.reload()
                buildColorRow()
            }
            colorRow.addView(dot)
        }
    }

    private fun bindSeek(id: Int, key: String, default: Int, min: Int) {
        val bar = findViewById<SeekBar>(id)
        bar.progress = prefs.getInt(key, default) - min
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    prefs.edit().putInt(key, progress + min).apply()
                    preview.reload()
                }
            }

            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
    }

    private fun bindSwitch(id: Int, key: String, default: Boolean) {
        val sw = findViewById<MaterialSwitch>(id)
        sw.isChecked = prefs.getBoolean(key, default)
        sw.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(key, checked).apply()
            preview.reload()
        }
    }

    private fun runImport(block: () -> Boolean) {
        Thread {
            val ok = try {
                block()
            } catch (e: Exception) {
                false
            }
            runOnUiThread {
                Toast.makeText(
                    this,
                    if (ok) "Saved" else "Couldn't load that file",
                    Toast.LENGTH_SHORT
                ).show()
                fontSpinner.setSelection(prefs.getInt(ClockPrefs.KEY_FONT, 0))
                preview.reload()
            }
        }.start()
    }

    private fun applyWallpaper() {
        val component = ComponentName(this, ClockWallpaperService::class.java)
        val direct = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
            .putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, component)
        try {
            startActivity(direct)
        } catch (e: ActivityNotFoundException) {
            try {
                startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
            } catch (e2: ActivityNotFoundException) {
                Toast.makeText(
                    this,
                    "Open your Wallpaper settings and pick Glass Clock under live wallpapers",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
