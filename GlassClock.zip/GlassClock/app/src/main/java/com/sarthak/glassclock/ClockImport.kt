package com.sarthak.glassclock

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.graphics.Typeface
import android.net.Uri
import androidx.exifinterface.media.ExifInterface
import java.io.File
import java.io.FileOutputStream

/** Copies a picked photo / font into the app's private storage so the wallpaper can always read it. */
object ClockImport {

    fun importBackground(context: Context, uri: Uri): Boolean {
        val cr = context.contentResolver

        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) } ?: return false
        if (bounds.outWidth <= 0) return false

        var sample = 1
        val longest = maxOf(bounds.outWidth, bounds.outHeight)
        while (longest / sample > 2800) sample *= 2

        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        var bmp: Bitmap = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            ?: return false

        val orientation = cr.openInputStream(uri)?.use {
            ExifInterface(it).getAttributeInt(
                ExifInterface.TAG_ORIENTATION,
                ExifInterface.ORIENTATION_NORMAL
            )
        } ?: ExifInterface.ORIENTATION_NORMAL

        val degrees = when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
            else -> 0f
        }
        if (degrees != 0f) {
            val m = Matrix().apply { postRotate(degrees) }
            bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        }

        val out = File(context.filesDir, "bg_${System.currentTimeMillis()}.jpg")
        FileOutputStream(out).use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }

        val prefs = ClockPrefs.prefs(context)
        val old = prefs.getString(ClockPrefs.KEY_BG, null)
        prefs.edit().putString(ClockPrefs.KEY_BG, out.absolutePath).apply()
        old?.let { File(it).delete() }
        return true
    }

    fun clearBackground(context: Context) {
        val prefs = ClockPrefs.prefs(context)
        val old = prefs.getString(ClockPrefs.KEY_BG, null)
        prefs.edit().remove(ClockPrefs.KEY_BG).apply()
        old?.let { File(it).delete() }
    }

    fun importFont(context: Context, uri: Uri): Boolean {
        val out = File(context.filesDir, "font_${System.currentTimeMillis()}.ttf")
        val copied = context.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(out).use { input.copyTo(it) }
            true
        } ?: false
        if (!copied) return false

        val valid = try {
            Typeface.createFromFile(out) != null
        } catch (e: Exception) {
            false
        }
        if (!valid) {
            out.delete()
            return false
        }

        val prefs = ClockPrefs.prefs(context)
        val old = prefs.getString(ClockPrefs.KEY_FONT_PATH, null)
        prefs.edit()
            .putString(ClockPrefs.KEY_FONT_PATH, out.absolutePath)
            .putInt(ClockPrefs.KEY_FONT, ClockPrefs.FONT_CUSTOM)
            .apply()
        old?.let { File(it).delete() }
        return true
    }
}
