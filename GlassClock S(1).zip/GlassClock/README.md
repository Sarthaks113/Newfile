# Glass Clock

An iPhone-style glass lock screen clock for Android, built as a live wallpaper with a settings screen.

## Features
- Tall, narrow glass digits with a dot, colon or no separator; horizontal or stacked layout
- Separate Height and Width sliders, letter spacing, vertical position
- Frosted glass effect: a blurred copy of your wallpaper shows through the digits, plus a coloured tint and a bright rim
- Colour palette: presets, hue / saturation / brightness sliders, or type a hex code
- Custom wallpaper photo, with darkening
- Depth effect: "Clock in front" or "Photo in front" (the subject of the photo overlaps the clock). The subject is cut out on the phone with Google ML Kit, or you can import your own transparent PNG
- Optional date line in three formats, 12/24-hour time, custom font file

## Build
Open in Android Studio, or use the GitHub Actions workflow to build `app-debug.apk`.
The subject cut-out needs Google Play services and internet the first time (it downloads a small model).
