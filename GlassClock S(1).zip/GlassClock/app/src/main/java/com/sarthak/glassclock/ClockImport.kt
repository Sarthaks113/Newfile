package com.sarthak.glassclock

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Rect
import android.graphics.Typeface
import android.net.Uri
import androidx.exifinterface.media.ExifInterface
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.subject.SubjectSegmentation
import com.google.mlkit.vision.segmentation.subject.SubjectSegmenterOptions
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.FloatBuffer
import java.util.concurrent.TimeUnit
import kotlin.math.abs

/**
 * Copies picked photos / fonts into the app's private storage so the wallpaper can always read
 * them, and creates the "subject cut-out" used for the depth effect.
 * All functions here do heavy work: call them from a background thread.
 */
object ClockImport {

    private const val MAX_SIDE = 2400

    fun importBackground(context: Context, uri: Uri): Boolean {
        val cr = context.contentResolver

        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        // With inJustDecodeBounds the decoder returns null on purpose; the size is written into `bounds`.
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return false

        var sample = 1
        val longest = maxOf(bounds.outWidth, bounds.outHeight)
        while (longest / sample > MAX_SIDE) sample *= 2

        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        var bmp: Bitmap = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            ?: return false

        val orientation = cr.openInputStream(uri)?.use {
            ExifInterface(it).getAttributeInt(
                ExifInterface.TAG_ORIENTATION,
                ExifInterface.ORIENTATION_NORMAL
            )
        } ?: ExifInterface.ORIENTATION_NORMAL

        val degrees = when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
            else -> 0f
        }
        if (degrees != 0f) {
            val m = Matrix().apply { postRotate(degrees) }
            bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        }

        val out = File(context.filesDir, "bg_${System.currentTimeMillis()}.jpg")
        FileOutputStream(out).use { bmp.compress(Bitmap.CompressFormat.JPEG, 93, it) }

        // A new photo makes the old cut-out invalid, so drop it.
        val prefs = ClockPrefs.prefs(context)
        val oldBg = prefs.getString(ClockPrefs.KEY_BG, null)
        val oldFg = prefs.getString(ClockPrefs.KEY_FG, null)
        prefs.edit()
            .putString(ClockPrefs.KEY_BG, out.absolutePath)
            .remove(ClockPrefs.KEY_FG)
            .apply()
        oldBg?.let { File(it).delete() }
        oldFg?.let { File(it).delete() }
        return true
    }

    fun clearBackground(context: Context) {
        val prefs = ClockPrefs.prefs(context)
        val oldBg = prefs.getString(ClockPrefs.KEY_BG, null)
        val oldFg = prefs.getString(ClockPrefs.KEY_FG, null)
        prefs.edit()
            .remove(ClockPrefs.KEY_BG)
            .remove(ClockPrefs.KEY_FG)
            .putBoolean(ClockPrefs.KEY_DEPTH, false)
            .apply()
        oldBg?.let { File(it).delete() }
        oldFg?.let { File(it).delete() }
    }

    /**
     * Cuts the main subject out of the background photo with Google ML Kit (runs on the phone).
     * Returns null on success, otherwise a message to show the user.
     */
    fun autoCutout(context: Context): String? {
        val prefs = ClockPrefs.prefs(context)
        val bgPath = prefs.getString(ClockPrefs.KEY_BG, null) ?: return "Choose a background photo first"
        val bg = BitmapFactory.decodeFile(bgPath) ?: return "Couldn't read the background photo"

        // Segment a smaller copy (faster); the mask is scaled back up afterwards.
        val longest = maxOf(bg.width, bg.height)
        val small = if (longest > 1280) {
            val s = 1280f / longest
            Bitmap.createScaledBitmap(
                bg,
                maxOf(1, (bg.width * s).toInt()),
                maxOf(1, (bg.height * s).toInt()),
                true
            )
        } else {
            bg
        }

        val options = SubjectSegmenterOptions.Builder()
            .enableForegroundConfidenceMask()
            .build()
        val segmenter = SubjectSegmentation.getClient(options)

        // The first time, Google Play services has to download the model, so retry for a while.
        var mask: FloatBuffer? = null
        try {
            for (attempt in 1..15) {
                try {
                    val result = Tasks.await(
                        segmenter.process(InputImage.fromBitmap(small, 0)),
                        60,
                        TimeUnit.SECONDS
                    )
                    mask = result.foregroundConfidenceMask
                    break
                } catch (e: Exception) {
                    Thread.sleep(4000)
                }
            }
        } finally {
            (segmenter as? java.io.Closeable)?.close()
        }
        val buf = mask
            ?: return "Couldn't auto-cut the subject. It needs Google Play services and internet the first time. " +
                "You can use your own PNG cutout instead."

        val mw = small.width
        val mh = small.height
        buf.rewind()
        if (buf.remaining() < mw * mh) return "Couldn't read the cut-out result"

        val bytes = ByteArray(mw * mh)
        var covered = 0
        for (i in bytes.indices) {
            val c = buf.get(i)
            if (c > 0.5f) covered++
            // steepen the edge a little so the outline is crisp
            val a = ((c - 0.5f) * 3f + 0.5f).coerceIn(0f, 1f)
            bytes[i] = (a * 255f).toInt().toByte()
        }
        if (covered.toFloat() < mw * mh * 0.02f) {
            return "No clear subject found in this photo. You can use your own PNG cutout instead."
        }

        val maskBmp = Bitmap.createBitmap(mw, mh, Bitmap.Config.ALPHA_8)
        maskBmp.copyPixelsFromBuffer(ByteBuffer.wrap(bytes))

        // Full-resolution photo x scaled-up mask = sharp cut-out with transparent background.
        val fg = Bitmap.createBitmap(bg.width, bg.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(fg)
        canvas.drawBitmap(bg, 0f, 0f, null)
        val maskPaint = Paint(Paint.FILTER_BITMAP_FLAG).apply {
            xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
        }
        canvas.drawBitmap(maskBmp, null, Rect(0, 0, bg.width, bg.height), maskPaint)

        val out = File(context.filesDir, "fg_${System.currentTimeMillis()}.png")
        FileOutputStream(out).use { fg.compress(Bitmap.CompressFormat.PNG, 100, it) }

        val old = prefs.getString(ClockPrefs.KEY_FG, null)
        prefs.edit().putString(ClockPrefs.KEY_FG, out.absolutePath).apply()
        old?.let { File(it).delete() }
        return null
    }

    /** Uses a transparent PNG made elsewhere (for example with remove.bg) as the front layer. */
    fun importCutout(context: Context, uri: Uri): String? {
        val prefs = ClockPrefs.prefs(context)
        val bgPath = prefs.getString(ClockPrefs.KEY_BG, null) ?: return "Choose a background photo first"

        val bgBounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(bgPath, bgBounds)
        if (bgBounds.outWidth <= 0 || bgBounds.outHeight <= 0) return "Couldn't read the background photo"

        val out = File(context.filesDir, "fg_${System.currentTimeMillis()}.png")
        val copied = context.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(out).use { input.copyTo(it) }
            true
        } ?: false
        if (!copied) return "Couldn't open that file"

        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(out.absolutePath, o)
        if (o.outWidth <= 0 || o.outHeight <= 0) {
            out.delete()
            return "That file isn't a valid image"
        }
        val cutRatio = o.outWidth.toFloat() / o.outHeight
        val bgRatio = bgBounds.outWidth.toFloat() / bgBounds.outHeight
        if (abs(cutRatio - bgRatio) / bgRatio > 0.03f) {
            out.delete()
            return "The cutout must have the same shape (width : height) as your background photo"
        }

        val old = prefs.getString(ClockPrefs.KEY_FG, null)
        prefs.edit().putString(ClockPrefs.KEY_FG, out.absolutePath).apply()
        old?.let { File(it).delete() }
        return null
    }

    fun importFont(context: Context, uri: Uri): Boolean {
        val out = File(context.filesDir, "font_${System.currentTimeMillis()}.ttf")
        val copied = context.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(out).use { input.copyTo(it) }
            true
        } ?: false
        if (!copied) return false

        val valid = try {
            Typeface.createFromFile(out) != null
        } catch (e: Exception) {
            false
        }
        if (!valid) {
            out.delete()
            return false
        }

        val prefs = ClockPrefs.prefs(context)
        val old = prefs.getString(ClockPrefs.KEY_FONT_PATH, null)
        prefs.edit()
            .putString(ClockPrefs.KEY_FONT_PATH, out.absolutePath)
            .putInt(ClockPrefs.KEY_FONT, ClockPrefs.FONT_CUSTOM)
            .apply()
        old?.let { File(it).delete() }
        return true
    }
}
