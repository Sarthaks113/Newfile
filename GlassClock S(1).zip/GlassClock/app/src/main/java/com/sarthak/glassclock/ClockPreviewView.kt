package com.sarthak.glassclock

import android.content.Context
import android.graphics.Canvas
import android.graphics.Path
import android.util.AttributeSet
import android.view.View

/** Phone-shaped live preview shown at the top of the settings screen. */
class ClockPreviewView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val renderer = ClockRenderer(context)
    private var config = ClockPrefs.load(context)
    private val clip = Path()

    private val ticker = object : Runnable {
        override fun run() {
            invalidate()
            postDelayed(this, 5000)
        }
    }

    init {
        // Software layer so shadows on the glass digits render exactly like the live wallpaper.
        setLayerType(LAYER_TYPE_SOFTWARE, null)
    }

    fun reload() {
        config = ClockPrefs.load(context)
        invalidate()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        post(ticker)
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(ticker)
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        val radius = 36f * resources.displayMetrics.density
        clip.reset()
        clip.addRoundRect(0f, 0f, width.toFloat(), height.toFloat(), radius, radius, Path.Direction.CW)
        canvas.save()
        canvas.clipPath(clip)
        renderer.draw(canvas, width, height, config)
        canvas.restore()
    }
}
