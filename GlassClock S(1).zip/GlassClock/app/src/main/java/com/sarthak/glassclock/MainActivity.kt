package com.sarthak.glassclock

import android.app.WallpaperManager
import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButtonToggleGroup
import com.google.android.material.materialswitch.MaterialSwitch

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var preview: ClockPreviewView
    private lateinit var fontSpinner: Spinner
    private lateinit var dateSpinner: Spinner
    private lateinit var depthToggle: MaterialButtonToggleGroup
    private lateinit var seekHue: SeekBar
    private lateinit var seekSat: SeekBar
    private lateinit var seekVal: SeekBar
    private lateinit var hexField: EditText
    private lateinit var swatch: View

    private var busy = false
    private var syncing = false

    private val presetColors = intArrayOf(
        0xFFFFFFFF.toInt(), 0xFFFFE0B2.toInt(), 0xFFFFCDD2.toInt(), 0xFFB3E5FC.toInt(),
        0xFFC8E6C9.toInt(), 0xFFFFF59D.toInt(), 0xFFE1BEE7.toInt(), 0xFF000000.toInt()
    )

    // ------------------------------------------------------------ pickers

    private val pickImage =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) {
                runTask("Loading photo...") {
                    if (!ClockImport.importBackground(this, uri)) {
                        "Couldn't load that photo"
                    } else if (prefs.getBoolean(ClockPrefs.KEY_DEPTH, false)) {
                        ClockImport.autoCutout(this)
                    } else {
                        null
                    }
                }
            }
        }

    private val pickFont =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) {
                runTask(null) {
                    if (ClockImport.importFont(this, uri)) null else "Couldn't load that font"
                }
            } else {
                refreshControls()
            }
        }

    private val pickCutout =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) {
                runTask("Loading cutout...") {
                    val error = ClockImport.importCutout(this, uri)
                    if (error == null) prefs.edit().putBoolean(ClockPrefs.KEY_DEPTH, true).apply()
                    error
                }
            }
        }

    // ------------------------------------------------------------ setup

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = ClockPrefs.prefs(this)
        preview = findViewById(R.id.preview)
        fontSpinner = findViewById(R.id.fontSpinner)
        dateSpinner = findViewById(R.id.dateSpinner)
        depthToggle = findViewById(R.id.depthToggle)

        bindToggles()
        bindSpinners()
        bindColor()

        bindSeek(R.id.seekHeight, ClockPrefs.KEY_HEIGHT, ClockPrefs.DEF_HEIGHT, 10)
        bindSeek(R.id.seekWidth, ClockPrefs.KEY_WIDTH, ClockPrefs.DEF_WIDTH, 20)
        bindSeek(R.id.seekSpacing, ClockPrefs.KEY_SPACING, ClockPrefs.DEF_SPACING, 0)
        bindSeek(R.id.seekY, ClockPrefs.KEY_Y, ClockPrefs.DEF_Y, 5)
        bindSeek(R.id.seekTint, ClockPrefs.KEY_TINT, ClockPrefs.DEF_TINT, 20)
        bindSeek(R.id.seekDim, ClockPrefs.KEY_DIM, ClockPrefs.DEF_DIM, 0)

        bindSwitch(R.id.switchGlass, ClockPrefs.KEY_GLASS, true)
        bindSwitch(R.id.switchDate, ClockPrefs.KEY_DATE, true)
        bindSwitch(R.id.switch24, ClockPrefs.KEY_24H, ClockPrefs.default24h(this))

        findViewById<View>(R.id.btnPickBg).setOnClickListener { pickImage.launch("image/*") }
        findViewById<View>(R.id.btnResetBg).setOnClickListener {
            ClockImport.clearBackground(this)
            refreshControls()
            preview.reload()
        }
        findViewById<View>(R.id.btnCustomFont).setOnClickListener { pickFont.launch("*/*") }
        findViewById<View>(R.id.btnPickCutout).setOnClickListener {
            if (prefs.getString(ClockPrefs.KEY_BG, null) == null) {
                toast("Choose a background photo first")
            } else {
                pickCutout.launch("image/*")
            }
        }
        findViewById<View>(R.id.btnRecut).setOnClickListener {
            if (prefs.getString(ClockPrefs.KEY_BG, null) == null) {
                toast("Choose a background photo first")
            } else {
                prefs.edit().putBoolean(ClockPrefs.KEY_DEPTH, true).apply()
                refreshControls()
                preview.reload()
                runTask("Cutting out the subject. The first time this can take a minute...") {
                    ClockImport.autoCutout(this)
                }
            }
        }
        findViewById<View>(R.id.btnApply).setOnClickListener { applyWallpaper() }
    }

    private fun bindToggles() {
        val style = findViewById<MaterialButtonToggleGroup>(R.id.styleToggle)
        style.check(
            if (prefs.getInt(ClockPrefs.KEY_STYLE, 0) == ClockPrefs.STYLE_STACKED) R.id.btnStacked
            else R.id.btnHorizontal
        )
        style.addOnButtonCheckedListener { _, id, checked ->
            if (checked) {
                val v = if (id == R.id.btnStacked) ClockPrefs.STYLE_STACKED else ClockPrefs.STYLE_HORIZONTAL
                prefs.edit().putInt(ClockPrefs.KEY_STYLE, v).apply()
                preview.reload()
            }
        }

        val sep = findViewById<MaterialButtonToggleGroup>(R.id.sepToggle)
        sep.check(
            when (prefs.getInt(ClockPrefs.KEY_SEP, ClockPrefs.SEP_DOT)) {
                ClockPrefs.SEP_COLON -> R.id.btnSepColon
                ClockPrefs.SEP_NONE -> R.id.btnSepNone
                else -> R.id.btnSepDot
            }
        )
        sep.addOnButtonCheckedListener { _, id, checked ->
            if (checked) {
                val v = when (id) {
                    R.id.btnSepColon -> ClockPrefs.SEP_COLON
                    R.id.btnSepNone -> ClockPrefs.SEP_NONE
                    else -> ClockPrefs.SEP_DOT
                }
                prefs.edit().putInt(ClockPrefs.KEY_SEP, v).apply()
                preview.reload()
            }
        }

        setDepthToggle(prefs.getBoolean(ClockPrefs.KEY_DEPTH, false))
        depthToggle.addOnButtonCheckedListener { _, id, checked ->
            if (!checked || syncing) return@addOnButtonCheckedListener
            val depth = id == R.id.btnPhotoFront
            if (depth && prefs.getString(ClockPrefs.KEY_BG, null) == null) {
                toast("Choose a background photo first")
                setDepthToggle(false)
                return@addOnButtonCheckedListener
            }
            prefs.edit().putBoolean(ClockPrefs.KEY_DEPTH, depth).apply()
            preview.reload()
            if (depth && prefs.getString(ClockPrefs.KEY_FG, null) == null) {
                runTask("Cutting out the subject. The first time this can take a minute...") {
                    ClockImport.autoCutout(this)
                }
            }
        }
    }

    private fun setDepthToggle(depth: Boolean) {
        syncing = true
        try {
            depthToggle.check(if (depth) R.id.btnPhotoFront else R.id.btnClockFront)
        } finally {
            syncing = false
        }
    }

    private fun bindSpinners() {
        val fonts = listOf("Condensed", "Bold", "Black", "Light", "Serif", "Mono", "Custom file")
        fontSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, fonts)
        fontSpinner.setSelection(prefs.getInt(ClockPrefs.KEY_FONT, 0))
        fontSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (pos == prefs.getInt(ClockPrefs.KEY_FONT, 0)) return
                if (pos == ClockPrefs.FONT_CUSTOM &&
                    prefs.getString(ClockPrefs.KEY_FONT_PATH, null) == null
                ) {
                    pickFont.launch("*/*")
                    return
                }
                prefs.edit().putInt(ClockPrefs.KEY_FONT, pos).apply()
                preview.reload()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        val dates = listOf("Saturday 19 September", "26/09/19  Saturday", "Sat, 19 Sep")
        dateSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, dates)
        dateSpinner.setSelection(prefs.getInt(ClockPrefs.KEY_DATEFMT, 0))
        dateSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (pos == prefs.getInt(ClockPrefs.KEY_DATEFMT, 0)) return
                prefs.edit().putInt(ClockPrefs.KEY_DATEFMT, pos).apply()
                preview.reload()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    // ------------------------------------------------------------ colour palette

    private fun bindColor() {
        seekHue = findViewById(R.id.seekHue)
        seekSat = findViewById(R.id.seekSat)
        seekVal = findViewById(R.id.seekVal)
        hexField = findViewById(R.id.hexField)
        swatch = findViewById(R.id.swatch)

        // Preset dots
        val row = findViewById<LinearLayout>(R.id.colorRow)
        for (c in presetColors) {
            val dot = View(this)
            dot.layoutParams = LinearLayout.LayoutParams(dp(44), dp(44)).apply { marginEnd = dp(10) }
            dot.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(c)
                setStroke(dp(1), 0x88888888.toInt())
            }
            dot.setOnClickListener { setColor(c, true) }
            row.addView(dot)
        }

        // Custom colour: hue / saturation / brightness sliders
        val listener = object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                val c = Color.HSVToColor(
                    floatArrayOf(
                        seekHue.progress.toFloat(),
                        seekSat.progress / 100f,
                        seekVal.progress / 100f
                    )
                )
                setColor(c, false)
            }

            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        }
        seekHue.setOnSeekBarChangeListener(listener)
        seekSat.setOnSeekBarChangeListener(listener)
        seekVal.setOnSeekBarChangeListener(listener)

        // Custom colour: type a hex code
        hexField.setOnEditorActionListener { v, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                val raw = v.text.toString().trim()
                try {
                    setColor(Color.parseColor(if (raw.startsWith("#")) raw else "#$raw"), true)
                } catch (e: IllegalArgumentException) {
                    toast("Use a colour like #FFD54F")
                }
                true
            } else {
                false
            }
        }

        syncColorControls(prefs.getInt(ClockPrefs.KEY_COLOR, Color.WHITE))
    }

    private fun setColor(c: Int, syncSliders: Boolean) {
        val color = c or (0xFF shl 24)
        prefs.edit().putInt(ClockPrefs.KEY_COLOR, color).apply()
        if (syncSliders) {
            syncColorControls(color)
        } else {
            updateSwatchAndHex(color)
        }
        preview.reload()
    }

    private fun syncColorControls(color: Int) {
        val hsv = FloatArray(3)
        Color.colorToHSV(color, hsv)
        seekHue.progress = hsv[0].toInt().coerceIn(0, 360)
        seekSat.progress = (hsv[1] * 100f).toInt().coerceIn(0, 100)
        seekVal.progress = (hsv[2] * 100f).toInt().coerceIn(0, 100)
        updateSwatchAndHex(color)
    }

    private fun updateSwatchAndHex(color: Int) {
        swatch.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(color)
            setStroke(dp(1), 0x88888888.toInt())
        }
        hexField.setText(String.format("#%06X", 0xFFFFFF and color))
    }

    // ------------------------------------------------------------ small helpers

    private fun bindSeek(id: Int, key: String, default: Int, min: Int) {
        val bar = findViewById<SeekBar>(id)
        bar.progress = prefs.getInt(key, default) - min
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    prefs.edit().putInt(key, progress + min).apply()
                    preview.reload()
                }
            }

            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
    }

    private fun bindSwitch(id: Int, key: String, default: Boolean) {
        val sw = findViewById<MaterialSwitch>(id)
        sw.isChecked = prefs.getBoolean(key, default)
        sw.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(key, checked).apply()
            preview.reload()
        }
    }

    /** Runs slow work off the main thread. The block returns null on success or an error message. */
    private fun runTask(working: String?, block: () -> String?) {
        if (busy) {
            toast("Please wait, still working...")
            return
        }
        busy = true
        if (working != null) toast(working)
        Thread {
            val error = try {
                block()
            } catch (e: Exception) {
                "Something went wrong: ${e.message}"
            }
            runOnUiThread {
                busy = false
                toast(error ?: "Done")
                refreshControls()
                preview.reload()
            }
        }.start()
    }

    /** Puts the controls back in line with what is saved (after a photo/font/cutout change). */
    private fun refreshControls() {
        fontSpinner.setSelection(prefs.getInt(ClockPrefs.KEY_FONT, 0))
        setDepthToggle(prefs.getBoolean(ClockPrefs.KEY_DEPTH, false))
    }

    private fun applyWallpaper() {
        val component = ComponentName(this, ClockWallpaperService::class.java)
        val direct = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
            .putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, component)
        try {
            startActivity(direct)
        } catch (e: ActivityNotFoundException) {
            try {
                startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
            } catch (e2: ActivityNotFoundException) {
                toast("Open your Wallpaper settings and pick Glass Clock under live wallpapers")
            }
        }
    }

    private fun toast(message: String) =
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
