package com.sarthak.glassclock

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.graphics.Canvas
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import androidx.core.content.ContextCompat

class ClockWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine = ClockEngine()

    private inner class ClockEngine : Engine() {

        private val renderer = ClockRenderer(this@ClockWallpaperService)
        private var config = ClockPrefs.load(this@ClockWallpaperService)
        private var surfaceWidth = 0
        private var surfaceHeight = 0
        private var receiverRegistered = false

        private val timeReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                drawFrame()
            }
        }

        // Kept as a field: SharedPreferences only holds listeners weakly.
        private val prefsListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
            config = ClockPrefs.load(this@ClockWallpaperService)
            drawFrame()
        }

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            ClockPrefs.prefs(this@ClockWallpaperService)
                .registerOnSharedPreferenceChangeListener(prefsListener)
        }

        override fun onDestroy() {
            unregisterTimeReceiver()
            ClockPrefs.prefs(this@ClockWallpaperService)
                .unregisterOnSharedPreferenceChangeListener(prefsListener)
            super.onDestroy()
        }

        override fun onVisibilityChanged(visible: Boolean) {
            if (visible) {
                config = ClockPrefs.load(this@ClockWallpaperService)
                registerTimeReceiver()
                drawFrame()
            } else {
                unregisterTimeReceiver()
            }
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            surfaceWidth = width
            surfaceHeight = height
            drawFrame()
        }

        override fun onSurfaceRedrawNeeded(holder: SurfaceHolder) {
            super.onSurfaceRedrawNeeded(holder)
            drawFrame()
        }

        private fun registerTimeReceiver() {
            if (receiverRegistered) return
            val filter = IntentFilter().apply {
                addAction(Intent.ACTION_TIME_TICK)      // once a minute, only while visible
                addAction(Intent.ACTION_TIME_CHANGED)
                addAction(Intent.ACTION_TIMEZONE_CHANGED)
            }
            ContextCompat.registerReceiver(
                this@ClockWallpaperService,
                timeReceiver,
                filter,
                ContextCompat.RECEIVER_NOT_EXPORTED
            )
            receiverRegistered = true
        }

        private fun unregisterTimeReceiver() {
            if (!receiverRegistered) return
            try {
                unregisterReceiver(timeReceiver)
            } catch (e: IllegalArgumentException) {
                // already unregistered
            }
            receiverRegistered = false
        }

        private fun drawFrame() {
            if (surfaceWidth <= 0 || surfaceHeight <= 0) return
            val holder = surfaceHolder ?: return
            var canvas: Canvas? = null
            try {
                canvas = holder.lockCanvas()
                if (canvas != null) {
                    renderer.draw(canvas, surfaceWidth, surfaceHeight, config)
                }
            } catch (e: Exception) {
                // Surface may have been destroyed; nothing to do.
            } finally {
                if (canvas != null) {
                    try {
                        holder.unlockCanvasAndPost(canvas)
                    } catch (e: Exception) {
                        // ignore
                    }
                }
            }
        }
    }
}
