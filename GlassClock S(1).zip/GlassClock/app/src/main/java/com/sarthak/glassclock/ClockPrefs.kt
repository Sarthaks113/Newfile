package com.sarthak.glassclock

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.text.format.DateFormat

data class ClockConfig(
    val style: Int,
    val separator: Int,
    val fontIndex: Int,
    val customFontPath: String?,
    val color: Int,
    val heightPercent: Int,   // digit height as % of screen height
    val widthPercent: Int,    // horizontal stretch of the digits
    val spacingPercent: Int,  // letter spacing
    val yPercent: Int,
    val tintPercent: Int,
    val dimPercent: Int,
    val use24h: Boolean,
    val showDate: Boolean,
    val dateFormat: Int,
    val glass: Boolean,
    val depth: Boolean,       // true = photo subject drawn in FRONT of the clock
    val bgImagePath: String?,
    val fgImagePath: String?
)

object ClockPrefs {
    const val STYLE_HORIZONTAL = 0
    const val STYLE_STACKED = 1

    const val SEP_DOT = 0
    const val SEP_COLON = 1
    const val SEP_NONE = 2

    const val FONT_CUSTOM = 6

    const val KEY_STYLE = "style"
    const val KEY_SEP = "separator"
    const val KEY_FONT = "font"
    const val KEY_FONT_PATH = "font_path"
    const val KEY_COLOR = "color"
    const val KEY_HEIGHT = "height"
    const val KEY_WIDTH = "width"
    const val KEY_SPACING = "spacing"
    const val KEY_Y = "y"
    const val KEY_TINT = "tint"
    const val KEY_DIM = "dim"
    const val KEY_24H = "use24h"
    const val KEY_DATE = "show_date"
    const val KEY_DATEFMT = "date_format"
    const val KEY_GLASS = "glass"
    const val KEY_DEPTH = "depth"
    const val KEY_BG = "bg_path"
    const val KEY_FG = "fg_path"

    const val DEF_HEIGHT = 26
    const val DEF_WIDTH = 44
    const val DEF_SPACING = 4
    const val DEF_Y = 27
    const val DEF_TINT = 55
    const val DEF_DIM = 10

    fun prefs(context: Context): SharedPreferences =
        context.applicationContext.getSharedPreferences("glass_clock", Context.MODE_PRIVATE)

    fun default24h(context: Context): Boolean = DateFormat.is24HourFormat(context)

    fun load(context: Context): ClockConfig {
        val p = prefs(context)
        return ClockConfig(
            style = p.getInt(KEY_STYLE, STYLE_HORIZONTAL),
            separator = p.getInt(KEY_SEP, SEP_DOT),
            fontIndex = p.getInt(KEY_FONT, 0),
            customFontPath = p.getString(KEY_FONT_PATH, null),
            color = p.getInt(KEY_COLOR, Color.WHITE),
            heightPercent = p.getInt(KEY_HEIGHT, DEF_HEIGHT),
            widthPercent = p.getInt(KEY_WIDTH, DEF_WIDTH),
            spacingPercent = p.getInt(KEY_SPACING, DEF_SPACING),
            yPercent = p.getInt(KEY_Y, DEF_Y),
            tintPercent = p.getInt(KEY_TINT, DEF_TINT),
            dimPercent = p.getInt(KEY_DIM, DEF_DIM),
            use24h = p.getBoolean(KEY_24H, default24h(context)),
            showDate = p.getBoolean(KEY_DATE, true),
            dateFormat = p.getInt(KEY_DATEFMT, 0),
            glass = p.getBoolean(KEY_GLASS, true),
            depth = p.getBoolean(KEY_DEPTH, false),
            bgImagePath = p.getString(KEY_BG, null),
            fgImagePath = p.getString(KEY_FG, null)
        )
    }
}
