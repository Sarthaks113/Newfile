package com.sarthak.glassclock

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.Rect
import android.graphics.Shader
import android.graphics.Typeface
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import kotlin.math.max

/**
 * Draws the whole lock screen picture:
 *   1. background (photo or gradient)
 *   2. the clock (frosted-glass digits)
 *   3. optionally the cut-out subject of the photo, drawn OVER the clock (depth effect)
 * The same code is used by the live wallpaper and by the preview inside the app.
 */
class ClockRenderer(@Suppress("unused") private val context: Context) {

    private val timePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rimPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val datePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val coverPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val gradPaint = Paint()
    private val bounds = Rect()

    private var sceneKey: String? = null
    private var sceneBg: Bitmap? = null
    private var sceneFg: Bitmap? = null
    private var blurBitmap: Bitmap? = null
    private var blurShader: BitmapShader? = null

    private var typefaceKey: String? = null
    private var typeface: Typeface = Typeface.DEFAULT_BOLD

    fun draw(
        canvas: Canvas,
        w: Int,
        h: Int,
        cfg: ClockConfig,
        now: Calendar = Calendar.getInstance()
    ) {
        if (w <= 0 || h <= 0) return
        buildScene(w, h, cfg)
        sceneBg?.let { canvas.drawBitmap(it, 0f, 0f, null) }
        drawClock(canvas, w, h, cfg, now)
        sceneFg?.let { canvas.drawBitmap(it, 0f, 0f, null) }
    }

    // ---------------------------------------------------------------- clock

    private fun drawClock(canvas: Canvas, w: Int, h: Int, cfg: ClockConfig, now: Calendar) {
        val stacked = cfg.style == ClockPrefs.STYLE_STACKED

        // Work out a text size so the DIGITS are exactly the requested height.
        timePaint.reset()
        timePaint.isAntiAlias = true
        timePaint.typeface = resolveTypeface(cfg)
        timePaint.textAlign = Paint.Align.LEFT
        timePaint.textScaleX = cfg.widthPercent / 100f
        timePaint.letterSpacing = cfg.spacingPercent / 100f
        timePaint.textSize = 100f
        val unit = digitHeight(timePaint)
        if (unit <= 0f) return
        val targetH = h * cfg.heightPercent / 100f * (if (stacked) 0.6f else 1f)
        timePaint.textSize = 100f * targetH / unit
        val digitH = digitHeight(timePaint)

        val hour24 = now.get(Calendar.HOUR_OF_DAY)
        val hourText = if (cfg.use24h) {
            "%02d".format(hour24)
        } else {
            val hh = hour24 % 12
            (if (hh == 0) 12 else hh).toString()
        }
        val minText = "%02d".format(now.get(Calendar.MINUTE))

        datePaint.reset()
        datePaint.isAntiAlias = true
        datePaint.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        datePaint.textAlign = Paint.Align.CENTER
        datePaint.textSize = w * 0.048f
        val dateH = digitHeight(datePaint)
        val gapDate = dateH * 1.1f

        val gapLines = digitH * 0.12f
        val digitBlockH = if (stacked) digitH * 2f + gapLines else digitH
        val blockH = digitBlockH + (if (cfg.showDate) dateH + gapDate else 0f)

        var top = h * cfg.yPercent / 100f - blockH / 2f
        top = top.coerceIn(0f, max(0f, h - blockH))
        val cx = w / 2f
        var y = top

        if (cfg.showDate) {
            val pattern = when (cfg.dateFormat) {
                1 -> "yy/MM/dd  EEEE"
                2 -> "EEE, d MMM"
                else -> "EEEE d MMMM"
            }
            val dateText = SimpleDateFormat(pattern, Locale.getDefault()).format(now.time)
            datePaint.color = withAlpha(cfg.color, 235)
            datePaint.setShadowLayer(dateH * 0.25f, 0f, dateH * 0.1f, 0x55000000)
            canvas.drawText(dateText, cx, top + dateH, datePaint)
            y += dateH + gapDate
        }

        val digitsTop = y
        val baseline1 = digitsTop + digitH
        val baseline2 = digitsTop + digitH * 2f + gapLines

        // Horizontal layout: HOUR  separator  MINUTE, centred on the screen.
        val hourW = timePaint.measureText(hourText)
        val minW = timePaint.measureText(minText)
        val sepR = digitH * 0.045f
        val sepGap = digitH * 0.13f
        val sepSpace = if (cfg.separator == ClockPrefs.SEP_NONE) sepGap else sepGap * 2f + sepR * 2f
        val totalW = hourW + sepSpace + minW
        val hourX = (w - totalW) / 2f
        val sepCx = hourX + hourW + sepGap + sepR
        val minX = hourX + hourW + sepSpace
        val stackHourX = (w - hourW) / 2f
        val stackMinX = (w - minW) / 2f

        fun drawGlyphs(p: Paint) {
            if (stacked) {
                canvas.drawText(hourText, stackHourX, baseline1, p)
                canvas.drawText(minText, stackMinX, baseline2, p)
            } else {
                canvas.drawText(hourText, hourX, baseline1, p)
                when (cfg.separator) {
                    ClockPrefs.SEP_DOT ->
                        canvas.drawCircle(sepCx, baseline1 - digitH / 2f, sepR, p)
                    ClockPrefs.SEP_COLON -> {
                        canvas.drawCircle(sepCx, baseline1 - digitH * 0.32f, sepR, p)
                        canvas.drawCircle(sepCx, baseline1 - digitH * 0.68f, sepR, p)
                    }
                }
                canvas.drawText(minText, minX, baseline1, p)
            }
        }

        val yTop = digitsTop
        val yBottom = digitsTop + digitBlockH
        val tint = cfg.tintPercent / 100f
        val frost = blurShader

        if (cfg.glass && frost != null) {
            // 1) soft drop shadow
            timePaint.style = Paint.Style.FILL
            timePaint.shader = null
            timePaint.color = Color.BLACK
            timePaint.setShadowLayer(digitH * 0.05f, 0f, digitH * 0.02f, 0x66000000)
            drawGlyphs(timePaint)
            timePaint.clearShadowLayer()

            // 2) frosted fill: a heavily blurred copy of the wallpaper shows through the digits
            timePaint.shader = frost
            timePaint.color = Color.WHITE
            drawGlyphs(timePaint)

            // 3) glass tint in your colour, stronger at the top, fading towards the bottom
            val hi = withAlpha(cfg.color, (tint * 0.85f * 255f).toInt())
            val lo = withAlpha(cfg.color, (tint * 0.45f * 255f).toInt())
            timePaint.shader = LinearGradient(0f, yTop, 0f, yBottom, hi, lo, Shader.TileMode.CLAMP)
            timePaint.color = Color.BLACK   // opaque; the shader carries the transparency
            drawGlyphs(timePaint)

            // 4) thin bright rim, like light catching the edge of glass
            rimPaint.set(timePaint)
            rimPaint.style = Paint.Style.STROKE
            rimPaint.strokeWidth = max(1.5f, digitH * 0.012f)
            rimPaint.shader = LinearGradient(
                0f, yTop, 0f, yBottom,
                0xD9FFFFFF.toInt(), 0x26FFFFFF, Shader.TileMode.CLAMP
            )
            rimPaint.color = Color.BLACK
            drawGlyphs(rimPaint)
        } else {
            timePaint.style = Paint.Style.FILL
            timePaint.shader = null
            timePaint.color = withAlpha(cfg.color, ((0.35f + 0.65f * tint) * 255f).toInt())
            timePaint.setShadowLayer(digitH * 0.03f, 0f, digitH * 0.012f, 0x40000000)
            drawGlyphs(timePaint)
        }
    }

    private fun withAlpha(color: Int, alpha: Int): Int =
        (color and 0x00FFFFFF) or (alpha.coerceIn(0, 255) shl 24)

    private fun digitHeight(p: Paint): Float {
        p.getTextBounds("0", 0, 1, bounds)
        return bounds.height().toFloat()
    }

    private fun resolveTypeface(cfg: ClockConfig): Typeface {
        val key = "${cfg.fontIndex}|${cfg.customFontPath}"
        if (key == typefaceKey) return typeface
        typefaceKey = key
        typeface = try {
            when (cfg.fontIndex) {
                1 -> Typeface.create("sans-serif", Typeface.BOLD)
                2 -> Typeface.create("sans-serif-black", Typeface.NORMAL)
                3 -> Typeface.create("sans-serif-light", Typeface.NORMAL)
                4 -> Typeface.create(Typeface.SERIF, Typeface.BOLD)
                5 -> Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
                ClockPrefs.FONT_CUSTOM ->
                    if (cfg.customFontPath != null) Typeface.createFromFile(cfg.customFontPath)
                    else Typeface.DEFAULT_BOLD
                else -> Typeface.create("sans-serif-condensed", Typeface.BOLD)
            }
        } catch (e: Exception) {
            Typeface.DEFAULT_BOLD
        }
        return typeface
    }

    // ---------------------------------------------------------------- scene

    /** Builds (and caches) the background, the front cut-out and the blurred copy for the glass. */
    private fun buildScene(w: Int, h: Int, cfg: ClockConfig) {
        val key = "${cfg.bgImagePath}|${cfg.fgImagePath}|${cfg.depth}|${cfg.dimPercent}|${w}x$h"
        if (key == sceneKey && sceneBg != null) return
        sceneKey = key

        val oldBg = sceneBg
        val oldFg = sceneFg
        val oldBlur = blurBitmap

        val bg = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val bgCanvas = Canvas(bg)
        val photo = cfg.bgImagePath?.let { decodeSampled(it, w, h) }
        if (photo != null) {
            drawCover(bgCanvas, photo, w, h)
            if (cfg.dimPercent > 0) {
                bgCanvas.drawColor(Color.argb((cfg.dimPercent / 100f * 255f).toInt(), 0, 0, 0))
            }
            photo.recycle()
        } else {
            gradPaint.shader = LinearGradient(
                0f, 0f, 0f, h.toFloat(),
                intArrayOf(0xFF1F1147.toInt(), 0xFF4C3A9E.toInt(), 0xFFE38FA0.toInt()),
                floatArrayOf(0f, 0.55f, 1f),
                Shader.TileMode.CLAMP
            )
            bgCanvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), gradPaint)
        }
        sceneBg = bg

        var fg: Bitmap? = null
        if (cfg.depth && photo != null) {
            val cut = cfg.fgImagePath?.let { decodeSampled(it, w, h) }
            if (cut != null) {
                fg = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                val fgCanvas = Canvas(fg)
                drawCover(fgCanvas, cut, w, h)
                if (cfg.dimPercent > 0) {
                    // darken only the visible pixels of the cut-out, same as the background
                    fgCanvas.drawColor(
                        Color.argb((cfg.dimPercent / 100f * 255f).toInt(), 0, 0, 0),
                        PorterDuff.Mode.SRC_ATOP
                    )
                }
                cut.recycle()
            }
        }
        sceneFg = fg

        val blur = makeBlur(bg, w)
        blurBitmap = blur
        blurShader = BitmapShader(blur, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP).apply {
            setLocalMatrix(
                Matrix().apply {
                    setScale(w / blur.width.toFloat(), h / blur.height.toFloat())
                }
            )
        }

        oldBg?.recycle()
        oldFg?.recycle()
        oldBlur?.recycle()
    }

    /** Repeated halving (each step averages neighbouring pixels) gives a soft frosted blur. */
    private fun makeBlur(src: Bitmap, w: Int): Bitmap {
        val target = max(8, w / 32)
        var cur = src
        while (cur.width > target) {
            val nw = max(target, cur.width / 2)
            val nh = max(1, (cur.height.toLong() * nw / cur.width).toInt())
            val next = Bitmap.createScaledBitmap(cur, nw, nh, true)
            if (cur !== src) cur.recycle()
            if (next === cur) break
            cur = next
        }
        return cur
    }

    private fun drawCover(canvas: Canvas, bmp: Bitmap, w: Int, h: Int) {
        val s = max(w / bmp.width.toFloat(), h / bmp.height.toFloat())
        val dx = (w - bmp.width * s) / 2f
        val dy = (h - bmp.height * s) / 2f
        val m = Matrix().apply {
            postScale(s, s)
            postTranslate(dx, dy)
        }
        canvas.drawBitmap(bmp, m, coverPaint)
    }

    private fun decodeSampled(path: String, w: Int, h: Int): Bitmap? {
        return try {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(path, o)
            if (o.outWidth <= 0 || o.outHeight <= 0) return null
            var sample = 1
            while (o.outWidth / (sample * 2) >= w && o.outHeight / (sample * 2) >= h) {
                sample *= 2
            }
            BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample })
        } catch (e: Exception) {
            null
        }
    }
}
